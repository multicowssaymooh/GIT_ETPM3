var searchData=
[
  ['environ_487',['environ',['../syscalls_8c.html#aa006daaf11f1e2e45a6ababaf463212b',1,'syscalls.c']]],
  ['errno_488',['errno',['../syscalls_8c.html#ad65a8842cc674e3ddf69355898c0ecbf',1,'syscalls.c']]]
];
