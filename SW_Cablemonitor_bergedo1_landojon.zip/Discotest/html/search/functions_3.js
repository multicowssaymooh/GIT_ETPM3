var searchData=
[
  ['delay_5fus_424',['Delay_us',['../measure_8h.html#a19cbc2c54977f6422dc53734e11748fe',1,'Delay_us(uint32_t delay):&#160;measure.c'],['../measure_8c.html#a19cbc2c54977f6422dc53734e11748fe',1,'Delay_us(uint32_t delay):&#160;measure.c']]],
  ['display_5fpeak_5fpeak_425',['Display_peak_peak',['../menu_8h.html#ad3766cfb76249af1b7ff3d70b532f00c',1,'Display_peak_peak(uint16_t PP1, uint16_t PP2, uint16_t PP3):&#160;menu.c'],['../menu_8c.html#ad3766cfb76249af1b7ff3d70b532f00c',1,'Display_peak_peak(uint16_t PP1, uint16_t PP2, uint16_t PP3):&#160;menu.c']]],
  ['display_5fsignal_5fpads_426',['Display_Signal_Pads',['../menu_8h.html#a57af956ec3440d227325d50e8d07b167',1,'Display_Signal_Pads(uint16_t *PAD1, uint16_t *PAD2, uint16_t *PAD3):&#160;menu.c'],['../menu_8c.html#a57af956ec3440d227325d50e8d07b167',1,'Display_Signal_Pads(uint16_t *PAD1, uint16_t *PAD2, uint16_t *PAD3):&#160;menu.c']]],
  ['display_5ftype_5fof_5fmeasurement_427',['Display_Type_of_Measurement',['../menu_8h.html#a38a8d3c59f7ac4b87d748cef48a71569',1,'Display_Type_of_Measurement(type_of_measurement type):&#160;menu.c'],['../menu_8c.html#a38a8d3c59f7ac4b87d748cef48a71569',1,'Display_Type_of_Measurement(type_of_measurement type):&#160;menu.c']]]
];
