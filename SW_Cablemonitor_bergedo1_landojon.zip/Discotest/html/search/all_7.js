var searchData=
[
  ['g2_5fgpio_5fport_140',['G2_GPIO_Port',['../main_8h.html#aa11e7a03b111c9340a2980e291ee3f5d',1,'main.h']]],
  ['g2_5fpin_141',['G2_Pin',['../main_8h.html#ab050266fdc3d2f616af5fc927b201339',1,'main.h']]],
  ['g3_5fgpio_5fport_142',['G3_GPIO_Port',['../main_8h.html#a2443f93ccdf142fa33e2a54d7e9c6dd3',1,'main.h']]],
  ['g3_5fpin_143',['G3_Pin',['../main_8h.html#a7d9940ba3744f81954a1cc7ad5e3b5d6',1,'main.h']]],
  ['g4_5fgpio_5fport_144',['G4_GPIO_Port',['../main_8h.html#ac5892bc28409dc1a3a29eb33c53af6b6',1,'main.h']]],
  ['g4_5fpin_145',['G4_Pin',['../main_8h.html#af1efa3943526f1f6193cfc63946955a5',1,'main.h']]],
  ['g5_5fgpio_5fport_146',['G5_GPIO_Port',['../main_8h.html#adc6fe4b1393617f21ef21b1a926a0c45',1,'main.h']]],
  ['g5_5fpin_147',['G5_Pin',['../main_8h.html#a6ae2c6a9d65239cded49fd239fb56e4a',1,'main.h']]],
  ['g6_5fgpio_5fport_148',['G6_GPIO_Port',['../main_8h.html#ad1b2e9ac61f2039b4d26f0dca800c822',1,'main.h']]],
  ['g6_5fpin_149',['G6_Pin',['../main_8h.html#a5a3d481b99e38a5133628763e2c6d4c9',1,'main.h']]],
  ['g7_5fgpio_5fport_150',['G7_GPIO_Port',['../main_8h.html#a5fe600d6297638c6242c734b9384ea57',1,'main.h']]],
  ['g7_5fpin_151',['G7_Pin',['../main_8h.html#a0c860272f3c8efcf0147ce0971843885',1,'main.h']]],
  ['get_5fadc1_5fvalues_152',['Get_ADC1_Values',['../measure_8h.html#ac5e4d3ca3005c4f2a3103576271d357d',1,'Get_ADC1_Values(void):&#160;measure.c'],['../measure_8c.html#ac5e4d3ca3005c4f2a3103576271d357d',1,'Get_ADC1_Values(void):&#160;measure.c']]],
  ['get_5fadc3_5fvalues_153',['Get_ADC3_Values',['../measure_8h.html#a512f60472a91474ff08abcf7389cd275',1,'Get_ADC3_Values(void):&#160;measure.c'],['../measure_8c.html#a512f60472a91474ff08abcf7389cd275',1,'Get_ADC3_Values(void):&#160;measure.c']]],
  ['get_5fdirection_154',['Get_Direction',['../calculations_8h.html#a0b9e354dddd65372bb98445d2b050293',1,'Get_Direction(uint16_t PP1, uint16_t PP2, uint16_t PP3):&#160;calculations.c'],['../calculations_8c.html#a0b9e354dddd65372bb98445d2b050293',1,'Get_Direction(uint16_t PP1, uint16_t PP2, uint16_t PP3):&#160;calculations.c']]],
  ['get_5fmeasurement_5fdata_155',['Get_Measurement_Data',['../calculations_8h.html#ae7ef43b64742b37fb4325492e1985278',1,'Get_Measurement_Data(type_of_measurement type):&#160;calculations.c'],['../calculations_8c.html#ae7ef43b64742b37fb4325492e1985278',1,'Get_Measurement_Data(type_of_measurement type):&#160;calculations.c']]],
  ['gpio_2ec_156',['gpio.c',['../gpio_8c.html',1,'']]],
  ['gpio_2eh_157',['gpio.h',['../gpio_8h.html',1,'']]],
  ['gpio_5finitstruct_158',['GPIO_InitStruct',['../measure_8c.html#a591ddc56da281d4cfd518f035c174289',1,'measure.c']]],
  ['gyro_5fdisable_159',['gyro_disable',['../main_8h.html#a2ac9c311ff05671105348142908ecda3',1,'gyro_disable(void):&#160;main.c'],['../main_8c.html#a2ac9c311ff05671105348142908ecda3',1,'gyro_disable(void):&#160;main.c']]]
];
