var searchData=
[
  ['type_5fof_5fmeasurement_521',['type_of_measurement',['../calculations_8h.html#a85b4944b97167a524ab5b43172f8a30d',1,'calculations.h']]]
];
