var searchData=
[
  ['pc14_5fosc32_5fin_5fgpio_5fport_677',['PC14_OSC32_IN_GPIO_Port',['../main_8h.html#ac1324283f34366c96d7372e4ee4c603a',1,'main.h']]],
  ['pc14_5fosc32_5fin_5fpin_678',['PC14_OSC32_IN_Pin',['../main_8h.html#a7d43c0c8b91a6510d9f474f78f57e5c9',1,'main.h']]],
  ['pc15_5fosc32_5fout_5fgpio_5fport_679',['PC15_OSC32_OUT_GPIO_Port',['../main_8h.html#a77c4021efe27a551dc9d2884422b0fae',1,'main.h']]],
  ['pc15_5fosc32_5fout_5fpin_680',['PC15_OSC32_OUT_Pin',['../main_8h.html#a4b7e48c6ffe3574f97f8fce18cae84de',1,'main.h']]],
  ['ph0_5fosc_5fin_5fgpio_5fport_681',['PH0_OSC_IN_GPIO_Port',['../main_8h.html#af8885fc2f50640cd8bb5084cd998088b',1,'main.h']]],
  ['ph0_5fosc_5fin_5fpin_682',['PH0_OSC_IN_Pin',['../main_8h.html#addb0c037a01bd73baaf9f7d5a0379ac4',1,'main.h']]],
  ['ph1_5fosc_5fout_5fgpio_5fport_683',['PH1_OSC_OUT_GPIO_Port',['../main_8h.html#a5b80653bbe01e9d4f334c74bdc5bc9f6',1,'main.h']]],
  ['ph1_5fosc_5fout_5fpin_684',['PH1_OSC_OUT_Pin',['../main_8h.html#ac4d4c1fdbc6cd7491c705bd332f15693',1,'main.h']]]
];
