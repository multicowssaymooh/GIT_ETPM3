var searchData=
[
  ['init_523',['INIT',['../calculations_8h.html#a85b4944b97167a524ab5b43172f8a30da0cb1b2c6a7db1f1084886c98909a3f36',1,'calculations.h']]]
];
