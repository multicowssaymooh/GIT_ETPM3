var searchData=
[
  ['pads_531',['PADS',['../calculations_8h.html#a85b4944b97167a524ab5b43172f8a30da9991e36cf31cfda4bceee8e0f6f2512b',1,'calculations.h']]]
];
