var searchData=
[
  ['initialise_5fmonitor_5fhandles_457',['initialise_monitor_handles',['../syscalls_8c.html#a25c7f100d498300fff65568c2fcfe639',1,'syscalls.c']]]
];
