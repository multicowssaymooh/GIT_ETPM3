var searchData=
[
  ['coils_522',['COILS',['../calculations_8h.html#a85b4944b97167a524ab5b43172f8a30da9bcfa7337a4582147b14fb8885f8f3fd',1,'calculations.h']]]
];
