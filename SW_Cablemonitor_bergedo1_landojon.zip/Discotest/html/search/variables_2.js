var searchData=
[
  ['back_5fcolor_485',['back_color',['../struct_m_e_n_u__entry__t.html#a0fd107c268f85989486fd5e5aa6a538b',1,'MENU_entry_t']]],
  ['blink_486',['blink',['../calculations_8c.html#ab2fc8e2508158b8232828ad0db0ef3ab',1,'calculations.c']]]
];
