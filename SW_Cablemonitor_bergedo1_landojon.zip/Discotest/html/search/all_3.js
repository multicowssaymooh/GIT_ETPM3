var searchData=
[
  ['calculations_2ec_78',['calculations.c',['../calculations_8c.html',1,'']]],
  ['calculations_2eh_79',['calculations.h',['../calculations_8h.html',1,'']]],
  ['coils_80',['COILS',['../calculations_8h.html#a85b4944b97167a524ab5b43172f8a30da9bcfa7337a4582147b14fb8885f8f3fd',1,'calculations.h']]],
  ['continuous_5fmeasurement_81',['Continuous_Measurement',['../calculations_8h.html#aa2d5daaead8e69186ad9e4bd751ea696',1,'Continuous_Measurement(type_of_measurement type):&#160;calculations.c'],['../calculations_8c.html#aa2d5daaead8e69186ad9e4bd751ea696',1,'Continuous_Measurement(type_of_measurement type):&#160;calculations.c']]],
  ['crc_2ec_82',['crc.c',['../crc_8c.html',1,'']]],
  ['crc_2eh_83',['crc.h',['../crc_8h.html',1,'']]],
  ['csx_5fgpio_5fport_84',['CSX_GPIO_Port',['../main_8h.html#aea68d78ac26021df352188d0d929a9e1',1,'main.h']]],
  ['csx_5fpin_85',['CSX_Pin',['../main_8h.html#ad22659ae1cfd5315588e03f78d1e70c1',1,'main.h']]],
  ['cable_20monitor_86',['Cable Monitor',['../index.html',1,'']]]
];
