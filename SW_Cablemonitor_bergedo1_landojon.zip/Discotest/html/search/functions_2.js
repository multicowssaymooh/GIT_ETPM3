var searchData=
[
  ['continuous_5fmeasurement_423',['Continuous_Measurement',['../calculations_8h.html#aa2d5daaead8e69186ad9e4bd751ea696',1,'Continuous_Measurement(type_of_measurement type):&#160;calculations.c'],['../calculations_8c.html#aa2d5daaead8e69186ad9e4bd751ea696',1,'Continuous_Measurement(type_of_measurement type):&#160;calculations.c']]]
];
