var searchData=
[
  ['hsync_5fgpio_5fport_631',['HSYNC_GPIO_Port',['../main_8h.html#a4d28bae3636bc7640613d0a085b33175',1,'main.h']]],
  ['hsync_5fpin_632',['HSYNC_Pin',['../main_8h.html#abe46f7c234bd29982de3e94d22fbc886',1,'main.h']]]
];
