var searchData=
[
  ['find_5fpeakpeak_430',['Find_Peakpeak',['../calculations_8h.html#a4fb47fc0d7f70084c6a70ee3182df9d2',1,'Find_Peakpeak(uint16_t *array):&#160;calculations.c'],['../calculations_8c.html#a4fb47fc0d7f70084c6a70ee3182df9d2',1,'Find_Peakpeak(uint16_t *array):&#160;calculations.c']]]
];
