var searchData=
[
  ['vbus_5fhs_5fgpio_5fport_362',['VBUS_HS_GPIO_Port',['../main_8h.html#a58b891b8886e609501dcc2a6a573928a',1,'main.h']]],
  ['vbus_5fhs_5fpin_363',['VBUS_HS_Pin',['../main_8h.html#a4076914d81451a1e2b345c815d90a64a',1,'main.h']]],
  ['vsync_5fgpio_5fport_364',['VSYNC_GPIO_Port',['../main_8h.html#af90f7e80e51d3de008b9beda452025ab',1,'main.h']]],
  ['vsync_5fpin_365',['VSYNC_Pin',['../main_8h.html#aff84bfbeb88c913c272cb6894fc0717c',1,'main.h']]]
];
