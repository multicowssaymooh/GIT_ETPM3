var searchData=
[
  ['off_665',['OFF',['../calculations_8c.html#a29e413f6725b2ba32d165ffaa35b01e5',1,'OFF():&#160;calculations.c'],['../main_8c.html#a29e413f6725b2ba32d165ffaa35b01e5',1,'OFF():&#160;main.c']]],
  ['on_666',['ON',['../calculations_8c.html#ad76d1750a6cdeebd506bfcd6752554d2',1,'ON():&#160;calculations.c'],['../main_8c.html#ad76d1750a6cdeebd506bfcd6752554d2',1,'ON():&#160;main.c']]],
  ['otg_5ffs_5foc_5fgpio_5fport_667',['OTG_FS_OC_GPIO_Port',['../main_8h.html#aace6961b24786e92b16a1491d5619873',1,'main.h']]],
  ['otg_5ffs_5foc_5fpin_668',['OTG_FS_OC_Pin',['../main_8h.html#a9dac7e1e728006ac65be0edd760aa160',1,'main.h']]],
  ['otg_5ffs_5fpso_5fgpio_5fport_669',['OTG_FS_PSO_GPIO_Port',['../main_8h.html#ac91b43b5bd6b5861221927f724b59aa9',1,'main.h']]],
  ['otg_5ffs_5fpso_5fpin_670',['OTG_FS_PSO_Pin',['../main_8h.html#a67f342826b1f3173f3ed3af3fd09d1bc',1,'main.h']]],
  ['otg_5fhs_5fdm_5fgpio_5fport_671',['OTG_HS_DM_GPIO_Port',['../main_8h.html#a219ac0a1be592fbb3f1f20b6a4987654',1,'main.h']]],
  ['otg_5fhs_5fdm_5fpin_672',['OTG_HS_DM_Pin',['../main_8h.html#a7ca18de87c06feae238fd466ff72ded6',1,'main.h']]],
  ['otg_5fhs_5fdp_5fgpio_5fport_673',['OTG_HS_DP_GPIO_Port',['../main_8h.html#ab432912ab14d3b9169036f6b055c7f63',1,'main.h']]],
  ['otg_5fhs_5fdp_5fpin_674',['OTG_HS_DP_Pin',['../main_8h.html#a48f7f7313df69260a4b5640c9fcb83c0',1,'main.h']]],
  ['otg_5fhs_5fid_5fgpio_5fport_675',['OTG_HS_ID_GPIO_Port',['../main_8h.html#ae6286149246b52cb48a531a21bc2bfad',1,'main.h']]],
  ['otg_5fhs_5fid_5fpin_676',['OTG_HS_ID_Pin',['../main_8h.html#a359f39e553ad4476f8f79012931a0c54',1,'main.h']]]
];
