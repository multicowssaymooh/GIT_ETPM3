var searchData=
[
  ['set_5fleds_5fdirection_477',['set_LEDs_direction',['../menu_8h.html#a05b41340719d6f383e67b962589bbf31',1,'set_LEDs_direction(uint8_t number, uint8_t state):&#160;menu.c'],['../menu_8c.html#a05b41340719d6f383e67b962589bbf31',1,'set_LEDs_direction(uint8_t number, uint8_t state):&#160;menu.c']]],
  ['single_5fmeasurement_478',['Single_Measurement',['../calculations_8h.html#ab5198f335d99998e989af5e09ed52d34',1,'Single_Measurement(type_of_measurement type):&#160;calculations.c'],['../calculations_8c.html#ab5198f335d99998e989af5e09ed52d34',1,'Single_Measurement(type_of_measurement type):&#160;calculations.c']]],
  ['systemclock_5fconfig_479',['SystemClock_Config',['../main_8c.html#a70af21c671abfcc773614a9a4f63d920',1,'main.c']]]
];
