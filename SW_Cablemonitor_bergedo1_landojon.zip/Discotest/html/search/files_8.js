var searchData=
[
  ['spi_2ec_394',['spi.c',['../spi_8c.html',1,'']]],
  ['spi_2eh_395',['spi.h',['../spi_8h.html',1,'']]],
  ['syscalls_2ec_396',['syscalls.c',['../syscalls_8c.html',1,'']]],
  ['sysmem_2ec_397',['sysmem.c',['../sysmem_8c.html',1,'']]]
];
