var searchData=
[
  ['nbl0_5fgpio_5fport_267',['NBL0_GPIO_Port',['../main_8h.html#a314915773692fbb7bc909f9bb23e280c',1,'main.h']]],
  ['nbl0_5fpin_268',['NBL0_Pin',['../main_8h.html#a26ddf96ececbe97b4a63bca01d194470',1,'main.h']]],
  ['nbl1_5fgpio_5fport_269',['NBL1_GPIO_Port',['../main_8h.html#ad8342df714a63fff76be12d18bbe2833',1,'main.h']]],
  ['nbl1_5fpin_270',['NBL1_Pin',['../main_8h.html#ac2b931b333138fe0da6d7571475c9114',1,'main.h']]],
  ['no_5fsamples_271',['NO_SAMPLES',['../calculations_8c.html#afe08e603a627b3d0e92e5daf3f7e1468',1,'calculations.c']]]
];
