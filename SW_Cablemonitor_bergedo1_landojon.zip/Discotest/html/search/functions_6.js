var searchData=
[
  ['get_5fadc1_5fvalues_431',['Get_ADC1_Values',['../measure_8h.html#ac5e4d3ca3005c4f2a3103576271d357d',1,'Get_ADC1_Values(void):&#160;measure.c'],['../measure_8c.html#ac5e4d3ca3005c4f2a3103576271d357d',1,'Get_ADC1_Values(void):&#160;measure.c']]],
  ['get_5fadc3_5fvalues_432',['Get_ADC3_Values',['../measure_8h.html#a512f60472a91474ff08abcf7389cd275',1,'Get_ADC3_Values(void):&#160;measure.c'],['../measure_8c.html#a512f60472a91474ff08abcf7389cd275',1,'Get_ADC3_Values(void):&#160;measure.c']]],
  ['get_5fdirection_433',['Get_Direction',['../calculations_8h.html#a0b9e354dddd65372bb98445d2b050293',1,'Get_Direction(uint16_t PP1, uint16_t PP2, uint16_t PP3):&#160;calculations.c'],['../calculations_8c.html#a0b9e354dddd65372bb98445d2b050293',1,'Get_Direction(uint16_t PP1, uint16_t PP2, uint16_t PP3):&#160;calculations.c']]],
  ['get_5fmeasurement_5fdata_434',['Get_Measurement_Data',['../calculations_8h.html#ae7ef43b64742b37fb4325492e1985278',1,'Get_Measurement_Data(type_of_measurement type):&#160;calculations.c'],['../calculations_8c.html#ae7ef43b64742b37fb4325492e1985278',1,'Get_Measurement_Data(type_of_measurement type):&#160;calculations.c']]],
  ['gyro_5fdisable_435',['gyro_disable',['../main_8h.html#a2ac9c311ff05671105348142908ecda3',1,'gyro_disable(void):&#160;main.c'],['../main_8c.html#a2ac9c311ff05671105348142908ecda3',1,'gyro_disable(void):&#160;main.c']]]
];
